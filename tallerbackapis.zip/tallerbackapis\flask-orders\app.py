import os
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP

from flask import Flask, jsonify, request
from psycopg2.extras import execute_values
from psycopg2.pool import ThreadedConnectionPool

app = Flask(__name__)

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "5433")),
    "user": os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", "postgres"),
    "dbname": os.getenv("DB_NAME", "orders_db"),
}
POOL_MIN = int(os.getenv("DB_POOL_MIN", "2"))
POOL_MAX = int(os.getenv("DB_POOL_MAX", "20"))

_pool = None


def get_pool():
    # Pool creado de forma perezosa: cada worker de gunicorn tiene el suyo.
    global _pool
    if _pool is None:
        _pool = ThreadedConnectionPool(POOL_MIN, POOL_MAX, **DB_CONFIG)
    return _pool


@contextmanager
def db_connection():
    pool = get_pool()
    conn = pool.getconn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pool.putconn(conn)


def validate(payload):
    if not isinstance(payload, dict):
        return "El cuerpo debe ser un objeto JSON"
    if not isinstance(payload.get("customerId"), str) or not payload["customerId"].strip():
        return "customerId es obligatorio"
    items = payload.get("items")
    if not isinstance(items, list) or not items:
        return "items debe ser una lista no vacía"
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            return f"items[{i}] debe ser un objeto"
        if not isinstance(item.get("productId"), str) or not item["productId"].strip():
            return f"items[{i}].productId es obligatorio"
        qty = item.get("quantity")
        if not isinstance(qty, int) or isinstance(qty, bool) or qty <= 0:
            return f"items[{i}].quantity debe ser un entero > 0"
        price = item.get("price")
        if not isinstance(price, (int, float)) or isinstance(price, bool) or price < 0:
            return f"items[{i}].price debe ser un número >= 0"
    return None


@app.post("/api/orders")
def create_order():
    payload = request.get_json(silent=True)
    error = validate(payload)
    if error:
        return jsonify({"error": error}), 400

    customer_id = payload["customerId"]
    items = payload["items"]

    # 1. Calcular totalAmount e itemsCount
    total = sum(Decimal(str(it["price"])) * it["quantity"] for it in items)
    total_amount = total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    items_count = sum(it["quantity"] for it in items)

    order_id = str(uuid.uuid4())
    processed_at = datetime.now(timezone.utc)

    # 2. Insertar en orders y order_items en una sola transacción
    with db_connection() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO orders (order_id, customer_id, total_amount, items_count, created_at)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (order_id, customer_id, total_amount, items_count, processed_at.replace(tzinfo=None)),
        )
        execute_values(
            cur,
            "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES %s",
            [(order_id, it["productId"], it["quantity"], Decimal(str(it["price"]))) for it in items],
        )

    # 3. Responder con orderId, totales y fecha de procesamiento
    return jsonify({
        "orderId": order_id,
        "customerId": customer_id,
        "totalAmount": float(total_amount),
        "itemsCount": items_count,
        "processedAt": processed_at.isoformat(),
    }), 201


@app.get("/health")
def health():
    try:
        with db_connection() as conn, conn.cursor() as cur:
            cur.execute("SELECT 1")
        return jsonify({"status": "ok"})
    except Exception as exc:  # noqa: BLE001
        return jsonify({"status": "error", "detail": str(exc)}), 503


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5001")))

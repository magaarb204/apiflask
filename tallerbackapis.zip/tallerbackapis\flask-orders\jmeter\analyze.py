"""Calcula métricas de los .jtl de JMeter y del consumo de docker stats.

Uso:
  python analyze.py <carpeta results>      -> imprime tablas Markdown
  python analyze.py --check <archivo.jtl>  -> imprime OK / STRESS
"""
import csv
import glob
import os
import re
import sys

STRESS_ERROR_PCT = 1.0
STRESS_P95_MS = 1000


def percentile(values, p):
    if not values:
        return 0
    values = sorted(values)
    k = max(0, int(round(p / 100 * len(values) + 0.5)) - 1)
    return values[min(k, len(values) - 1)]


def jtl_metrics(path):
    elapsed, errors, start, end = [], 0, None, None
    codes = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            e = int(row["elapsed"])
            ts = int(row["timeStamp"])
            elapsed.append(e)
            ok = row["success"] == "true"
            if not ok:
                errors += 1
                codes[row["responseCode"]] = codes.get(row["responseCode"], 0) + 1
            start = ts if start is None else min(start, ts)
            end = ts + e if end is None else max(end, ts + e)
    n = len(elapsed)
    secs = max((end - start) / 1000, 0.001) if n else 1
    return {
        "samples": n,
        "avg": sum(elapsed) / n if n else 0,
        "p90": percentile(elapsed, 90),
        "p95": percentile(elapsed, 95),
        "max": max(elapsed) if n else 0,
        "throughput": n / secs,
        "error_pct": 100 * errors / n if n else 0,
        "error_codes": codes,
    }


def to_mib(s):
    m = re.match(r"([\d.]+)\s*([KMG]i?B)", s.strip())
    if not m:
        return 0.0
    v, unit = float(m.group(1)), m.group(2)
    return v / 1024 if unit.startswith("K") else v * 1024 if unit.startswith("G") else v


def docker_metrics(path):
    data = {}
    if not os.path.exists(path):
        return data
    with open(path, encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split(";")
            if len(parts) != 4 or parts[0] == "Timestamp":
                continue
            _, name, cpu, mem = parts
            d = data.setdefault(name, {"cpu": [], "mem": []})
            d["cpu"].append(float(cpu.rstrip("%") or 0))
            d["mem"].append(to_mib(mem.split("/")[0]))
    out = {}
    for name, d in data.items():
        out[name] = {
            "cpu_avg": sum(d["cpu"]) / len(d["cpu"]),
            "cpu_max": max(d["cpu"]),
            "mem_max": max(d["mem"]),
        }
    return out


def main():
    if sys.argv[1] == "--check":
        m = jtl_metrics(sys.argv[2])
        stressed = m["error_pct"] > STRESS_ERROR_PCT or m["p95"] > STRESS_P95_MS
        print(f"{'STRESS' if stressed else 'OK'}: avg={m['avg']:.0f}ms p95={m['p95']}ms "
              f"tput={m['throughput']:.0f}/s err={m['error_pct']:.2f}%")
        return

    folder = sys.argv[1]
    rows = []
    for jtl in sorted(glob.glob(os.path.join(folder, "*.jtl"))):
        name = os.path.splitext(os.path.basename(jtl))[0]
        m = jtl_metrics(jtl)
        d = docker_metrics(os.path.join(folder, f"docker-stats-{name}.csv"))
        rows.append((name, m, d))

    print("| Escenario | Muestras | Avg (ms) | P90 (ms) | P95 (ms) | Max (ms) | Throughput (req/s) | % Error |")
    print("|---|---|---|---|---|---|---|---|")
    for name, m, _ in rows:
        print(f"| {name} | {m['samples']} | {m['avg']:.1f} | {m['p90']} | {m['p95']} | {m['max']} | "
              f"{m['throughput']:.1f} | {m['error_pct']:.2f}% |")
    print()
    print("| Escenario | CPU API prom/máx (%) | RAM API máx (MiB) | CPU DB prom/máx (%) | RAM DB máx (MiB) |")
    print("|---|---|---|---|---|")
    for name, _, d in rows:
        a, b = d.get("api-orders", {}), d.get("db-orders", {})
        print(f"| {name} | {a.get('cpu_avg', 0):.0f} / {a.get('cpu_max', 0):.0f} | {a.get('mem_max', 0):.0f} | "
              f"{b.get('cpu_avg', 0):.0f} / {b.get('cpu_max', 0):.0f} | {b.get('mem_max', 0):.0f} |")
    errs = [(n, m["error_codes"]) for n, m, _ in rows if m["error_codes"]]
    if errs:
        print("\nCódigos de error:", errs)


if __name__ == "__main__":
    main()

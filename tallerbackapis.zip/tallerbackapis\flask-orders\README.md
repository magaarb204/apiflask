# Microservicio de Órdenes — Python + Flask + PostgreSQL

Implementación del stack **Python + Flask** para el taller *Benchmarking de APIs con Postgres usando JMeter*.

## 1. Stack elegido

| Componente      | Tecnología                                  |
|-----------------|---------------------------------------------|
| Lenguaje        | Python 3.12                                 |
| Framework web   | Flask 3.0                                   |
| Servidor WSGI   | Gunicorn 22 (worker `gthread`)              |
| Driver de BD    | psycopg2 (`ThreadedConnectionPool`)         |
| Base de datos   | PostgreSQL 16                               |
| Orquestación    | Docker Compose                              |

## 2. Estructura del proyecto

```
flask-orders/
├── app.py               # API Flask (endpoint POST /api/orders)
├── requirements.txt     # Dependencias de Python
├── Dockerfile           # Imagen de la API (gunicorn)
├── docker-compose.yml   # API + PostgreSQL
├── init.sql             # Creación de tablas orders y order_items
└── README.md            # Este documento
```

## 3. Endpoint: `POST /api/orders`

### Entrada

```json
{
  "customerId": "C123",
  "items": [
    { "productId": "P1", "quantity": 2, "price": 10.5 },
    { "productId": "P2", "quantity": 1, "price": 5.0 }
  ]
}
```

### Lo que hace la API

1. **Valida** el JSON (customerId obligatorio, items no vacío, quantity entero > 0, price ≥ 0). Si es inválido responde `400`.
2. **Calcula**:
   - `totalAmount` = Σ (price × quantity) → usando `Decimal` para evitar errores de punto flotante y redondeado a 2 decimales.
   - `itemsCount` = Σ quantity (unidades totales).
3. **Genera** un `orderId` único (UUID v4).
4. **Inserta** en PostgreSQL dentro de **una sola transacción**:
   - 1 fila en `orders`.
   - N filas en `order_items` con un único `INSERT` multi-fila (`execute_values`).
   Si algo falla se hace `ROLLBACK`, así nunca quedan órdenes a medias.
5. **Responde** `201 Created`:

```json
{
  "orderId": "ed1fdb6b-8f35-4e65-a796-b1e1d55a7910",
  "customerId": "C123",
  "totalAmount": 26.0,
  "itemsCount": 3,
  "processedAt": "2026-11-20T02:14:09.682931+00:00"
}
```

Adicionalmente hay un `GET /health` que verifica la conexión con la base de datos.

## 4. Base de datos

`init.sql` se monta en `/docker-entrypoint-initdb.d/`, por lo que Postgres crea las tablas automáticamente la primera vez que arranca:

```sql
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  order_id VARCHAR(50) UNIQUE NOT NULL,
  customer_id VARCHAR(50) NOT NULL,
  total_amount NUMERIC(10,2) NOT NULL,
  items_count INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id VARCHAR(50) NOT NULL,
  product_id VARCHAR(50) NOT NULL,
  quantity INT NOT NULL,
  price NUMERIC(10,2) NOT NULL
);
```

> Nota: el script solo se ejecuta si el volumen `dbdata` está vacío. Para reiniciar desde cero: `docker compose down -v`.

## 5. Decisiones de diseño (relevantes para el benchmark)

- **Gunicorn en vez del servidor de desarrollo de Flask.** `flask run` atiende peticiones de una en una y no es apto para pruebas de carga. Gunicorn corre **4 procesos × 8 hilos = 32 peticiones concurrentes**.
- **Worker `gthread`.** Por el GIL de Python, los hilos no ejecutan código Python en paralelo, pero sí se liberan mientras esperan a PostgreSQL (I/O), que es donde se pasa la mayor parte del tiempo de cada petición. Los procesos múltiples aprovechan varios núcleos.
- **Pool de conexiones** (`ThreadedConnectionPool`, máx. 10 por proceso → 40 en total, por debajo del límite de 100 de Postgres). Abrir una conexión nueva por petición costaría varios ms extra.
- **Una transacción + INSERT multi-fila** para minimizar viajes de ida y vuelta a la BD.
- **Sin ORM** (SQL directo con psycopg2) para no añadir sobrecarga.
- **Healthcheck en Postgres** + `depends_on: condition: service_healthy`, para que la API no arranque antes de que la BD esté lista.

Los workers e hilos se pueden ajustar sin recompilar cambiando `GUNICORN_WORKERS` y `GUNICORN_THREADS` en `docker-compose.yml`.

## 6. Cómo levantarlo

Requisitos: Docker Desktop corriendo.

```bash
cd flask-orders
docker compose up -d --build
docker ps
```

Debe mostrar `api-orders` (puerto **5001**) y `db-orders` (puerto **5433** → 5432, healthy).

## 7. Cómo probarlo

**PowerShell:**

```powershell
$body = '{"customerId":"C123","items":[{"productId":"P1","quantity":2,"price":10.5},{"productId":"P2","quantity":1,"price":5.0}]}'
Invoke-RestMethod -Method Post -Uri http://localhost:5001/api/orders -ContentType 'application/json' -Body $body
```

**curl:**

```bash
curl -X POST http://localhost:5001/api/orders -H "Content-Type: application/json" -d "{\"customerId\":\"C123\",\"items\":[{\"productId\":\"P1\",\"quantity\":2,\"price\":10.5},{\"productId\":\"P2\",\"quantity\":1,\"price\":5.0}]}"
```

**Verificar en la base de datos:**

```bash
docker exec db-orders psql -U postgres -d orders_db -c "SELECT * FROM orders;" -c "SELECT * FROM order_items;"
```

## 8. Verificación realizada

| Prueba | Resultado |
|---|---|
| POST con el JSON del enunciado | `201`, totalAmount = 26.0, itemsCount = 3 |
| Fila en `orders` | total_amount = 26.00, items_count = 3 |
| Filas en `order_items` | P1 (2 × 10.50) y P2 (1 × 5.00) |
| POST inválido (`{"items":[]}`) | `400` — "customerId es obligatorio" |
| 200 peticiones, 50 concurrentes | 200/200 con `201`, 0 errores, ~1.2 s |

## 9. Pruebas de carga con JMeter

Carpeta `jmeter/`:

| Archivo | Para qué |
|---|---|
| `benchmark-grupal.jmx` | Test Plan: HTTP Request Defaults (localhost:5001, `/api/orders`), HTTP Header Manager (`Content-Type: application/json`), 4 Thread Groups (Baja 10, Media 50, Alta 100, Estrés) con un HTTP Request POST cada uno, y listeners Summary Report + Aggregate Report. |
| `run-benchmark.ps1` | Corre todos los escenarios por consola, guarda `docker stats` en CSV y hace el estrés de 20 en 20 desde 120 usuarios hasta que haya > 1 % de errores o P95 > 1 s. |
| `analyze.py` | Calcula Avg, P90, P95, Throughput, % Error y CPU/RAM a partir de los resultados. |
| `results/` | `.jtl` (datos crudos), `*-html/` (dashboard HTML de JMeter) y `docker-stats-*.csv` por escenario. |
| `evidences/` | Carpetas `baja-10`, `media-50`, `alta-100`, `estres` para las capturas. |
| `../RESULTADOS_FLASK.md` | Tablas finales y observaciones para el grupo. |

Configuración actual: Loop Count = 5 y sin *Specify Thread Lifetime* en todos los escenarios; ramp-up de 10 s en baja (10) y media (50), y de 20 s en alta (100) y en cada escalón de estrés (120 → 280). Sin pausas entre peticiones. Política de BD: no se vacían las tablas entre corridas. Los Thread Groups usan propiedades (`${__P(baja,10)}` etc.), así que en la GUI salen con 10 / 50 / 100 usuarios y el de Estrés en 0 (desactivado); se ejecutan uno tras otro.

**Correr todo por consola:**

```powershell
cd jmeter
powershell -ExecutionPolicy Bypass -File .\run-benchmark.ps1
```

**Sacar las capturas para la entrega (GUI):**

1. Abrir JMeter: `C:\Users\LENOVO\apache-jmeter-5.6.3\bin\jmeter.bat`, luego File → Open → `benchmark-grupal.jmx`.
2. Para correr un solo escenario: clic derecho en los otros Thread Groups → *Disable*.
3. En otra terminal: `docker stats api-orders db-orders`. Para `htop` hace falta WSL con una distro Linux (p. ej. `wsl --install -d Ubuntu`, luego dentro: `sudo apt install htop` y `htop`).
4. Run ▶ y hacer la captura de JMeter durante la carga + docker stats.
5. Al terminar: capturas del **Summary Report** y del **Aggregate Report**, luego *Clear All* (escoba) antes del siguiente escenario.
6. Captura de `docker ps`.

> La GUI de JMeter consume CPU; para las métricas "oficiales" es mejor usar los números del modo consola (`RESULTADOS_FLASK.md`) y la GUI solo para las evidencias.

## 10. Comandos útiles durante el benchmark

```bash
docker stats api-orders db-orders     # CPU/RAM de los contenedores
docker logs -f api-orders             # logs de la API
docker compose down                   # detener
docker compose down -v                # detener y borrar los datos
docker exec db-orders psql -U postgres -d orders_db -c "TRUNCATE orders, order_items RESTART IDENTITY;"  # limpiar entre pruebas
```

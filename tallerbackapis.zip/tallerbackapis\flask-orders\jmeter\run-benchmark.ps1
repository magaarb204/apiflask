﻿# Ejecuta los escenarios del protocolo grupal con JMeter en modo consola
# y registra el consumo de los contenedores con docker stats (CSV).
#
# Configuración acordada por el grupo: ramp-up 5 s, duración 60 s,
# 10 / 50 / 100 usuarios y luego estrés de 20 en 20 desde 120.
#
# Uso:
#   powershell -ExecutionPolicy Bypass -File .\run-benchmark.ps1                 # todo
#   powershell -ExecutionPolicy Bypass -File .\run-benchmark.ps1 -Phase main     # solo 10/50/100
#   powershell -ExecutionPolicy Bypass -File .\run-benchmark.ps1 -Phase stress -StressStart 120 -StressMax 200
#
# Política de BD: NO se vacían las tablas entre corridas (agregar -CleanDb para hacerlo).

param(
    [ValidateSet("all", "main", "stress")][string]$Phase = "all",
    [int]$Duration = 60,
    [int]$RampUp = 5,
    [int]$StressStart = 120,
    [int]$StressStep = 20,
    [int]$StressMax = 400,
    [switch]$CleanDb,
    [string[]]$Only = @(),        # p. ej. -Only alta  (baja | media | alta)
    [string]$JMeterHome = "$env:USERPROFILE\apache-jmeter-5.6.3"
)

$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$plan = Join-Path $here "benchmark-grupal.jmx"
$out  = Join-Path $here "results"
New-Item -ItemType Directory -Force $out | Out-Null

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    $jdk = Get-ChildItem "C:\Program Files\Eclipse Adoptium" -Directory -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($jdk) { $env:JAVA_HOME = $jdk.FullName; $env:Path = "$($jdk.FullName)\bin;$env:Path" }
}
$jmeter = Join-Path $JMeterHome "bin\jmeter.bat"

function Run-Scenario([string]$name, [hashtable]$users) {
    Write-Host "`n=== $name ===" -ForegroundColor Cyan
    if ($CleanDb) {
        docker exec db-orders psql -U postgres -d orders_db -q -c "TRUNCATE orders, order_items RESTART IDENTITY;" | Out-Null
    }
    $jtl   = Join-Path $out "$name.jtl"
    $html  = Join-Path $out "$name-html"
    $stats = Join-Path $out "docker-stats-$name.csv"
    Remove-Item $jtl, $stats -ErrorAction SilentlyContinue
    Remove-Item $html -Recurse -ErrorAction SilentlyContinue

    # Muestreo de docker stats en segundo plano mientras corre JMeter
    "Timestamp;Container;CPU_Percent;Memory_Usage" | Set-Content $stats
    $flag = Join-Path $out ".running"
    New-Item -ItemType File -Force $flag | Out-Null
    $job = Start-Job -ArgumentList $flag, $stats -ScriptBlock {
        param($flag, $stats)
        while (Test-Path $flag) {
            $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            docker stats --no-stream --format "{{.Name}};{{.CPUPerc}};{{.MemUsage}}" api-orders db-orders |
                ForEach-Object { "$ts;$_" } | Add-Content $stats
        }
    }

    $jargs = @("-n", "-t", $plan, "-l", $jtl, "-e", "-o", $html,
               "-Jduration=$Duration", "-Jrampup=$RampUp",
               "-Jbaja=$($users.baja)", "-Jmedia=$($users.media)",
               "-Jalta=$($users.alta)", "-Jestres=$($users.estres)")
    & $jmeter @jargs | Select-String "summary =" | Select-Object -Last 1

    Remove-Item $flag
    Wait-Job $job | Out-Null; Remove-Job $job
}

if ($Phase -in "all", "main") {
    if (-not $Only -or $Only -contains "baja")  { Run-Scenario "1-baja-10"  @{ baja = 10; media = 0;  alta = 0;   estres = 0 } }
    if (-not $Only -or $Only -contains "media") { Run-Scenario "2-media-50" @{ baja = 0;  media = 50; alta = 0;   estres = 0 } }
    if (-not $Only -or $Only -contains "alta")  { Run-Scenario "3-alta-100" @{ baja = 0;  media = 0;  alta = 100; estres = 0 } }
}

if ($Phase -in "all", "stress") {
    # Estrés: de 20 en 20 hasta observar estrés (errores > 1 % o P95 > 1000 ms)
    for ($u = $StressStart; $u -le $StressMax; $u += $StressStep) {
        $name = "4-estres-{0:D3}" -f $u
        Run-Scenario $name @{ baja = 0; media = 0; alta = 0; estres = $u }
        $check = python -I (Join-Path $here "analyze.py") --check (Join-Path $out "$name.jtl")
        Write-Host $check
        if ($check -like "STRESS*") { Write-Host "Estres detectado con $u usuarios." -ForegroundColor Yellow; break }
    }
}

python -I (Join-Path $here "analyze.py") $out

# Guía paso a paso — Capturas de evidencia (Flask)

Tiempo total aproximado: **40–50 minutos** (la primera vez, contando instalar htop).

---

## PARTE 0 — Preparación (una sola vez)

### 0.1 Instalar Ubuntu en WSL (para poder usar `htop`)

`htop` es un programa de Linux; en Windows se usa a través de WSL.

1. Abre **PowerShell como administrador** (clic derecho en Inicio → *Terminal (Administrador)*).
2. Escribe:
   ```
   wsl --install -d Ubuntu
   ```
3. Si te pide **reiniciar** el PC, reinícialo.
4. Al volver, se abre una ventana de Ubuntu que te pide crear un **usuario** y una **contraseña** (pueden ser cualquiera, por ejemplo `maria` / `1234`). Al escribir la contraseña no se ve nada en pantalla; es normal.
5. Dentro de esa ventana de Ubuntu escribe:
   ```
   sudo apt update
   sudo apt install -y htop
   ```
   (te pedirá la contraseña que acabas de crear).
6. Prueba que funciona escribiendo `htop`. Sale una pantalla con barras de colores. Para salir presiona **q**.

> Si ya tienes Ubuntu en WSL, salta directo al paso 5.

### 0.2 Crear una carpeta para guardar las capturas

Dentro del proyecto ya existen estas carpetas, guarda ahí cada captura:

```
flask-orders\jmeter\evidences\baja-10\
flask-orders\jmeter\evidences\media-50\
flask-orders\jmeter\evidences\alta-100\
flask-orders\jmeter\evidences\estres\
```

---

## PARTE 1 — Dejar todo listo antes de cada sesión de capturas

### 1.1 Abrir Docker Desktop
Ábrelo y espera a que abajo a la izquierda diga **Engine running** (verde).

### 1.2 Verificar que la API está arriba
Abre **VS Code** → *File → Open Folder* → `Documents\tallerbackapis\flask-orders`.
Abre una terminal (*Terminal → New Terminal*) y escribe:

```
docker compose up -d
docker ps
```

Deben aparecer `api-orders` (puerto 5001) y `db-orders` (healthy).

### 1.3 Abrir JMeter
1. Abre el Explorador de archivos y ve a `C:\Users\LENOVO\apache-jmeter-5.6.3\bin`.
2. Doble clic en **`jmeter.bat`**. Se abre una ventana negra (no la cierres) y luego la ventana de JMeter.
3. En JMeter: **File → Open** → `Documents\tallerbackapis\flask-orders\jmeter\benchmark-grupal.jmx`.

A la izquierda verás este árbol:

```
Benchmark grupal - Flask - POST /api/orders
├── HTTP Request Defaults
├── HTTP Header Manager
├── Baja carga
├── Media carga
├── Alta carga
├── Estres
├── Summary Report
└── Aggregate Report
```

> En los campos verás cosas como `${__P(baja,10)}` o `${__P(duration,60)}`. Significa "10 usuarios" y "60 segundos". No hay que cambiarlos (salvo en el estrés, ver más abajo).

### 1.4 Acomodar las ventanas
Ten abiertas estas 4 ventanas para ir cambiando entre ellas:

| Ventana | Qué escribir |
|---|---|
| **JMeter** | — |
| **Terminal 1** (VS Code o PowerShell, dentro de `flask-orders`) | `docker ps` |
| **Terminal 2** (otra pestaña) | `docker stats api-orders db-orders` (se queda actualizándose solo) |
| **Ubuntu** (busca "Ubuntu" en Inicio) | `htop` |

---

## PARTE 2 — Hacer un escenario (repetir 4 veces)

Se repite lo mismo para: **Baja (10) → Media (50) → Alta (100) → Estrés (280)**.

### Paso 1 — Dejar activo SOLO el escenario que vas a correr

En el árbol de la izquierda de JMeter:

| Vas a correr | Activo (Enable) | Desactivados (Disable) |
|---|---|---|
| **Baja** | Baja carga | Media carga, Alta carga, Estres |
| **Media** | Media carga | Baja carga, Alta carga, Estres |
| **Alta** | Alta carga | Baja carga, Media carga, Estres |
| **Estrés** | Estres | Baja carga, Media carga, Alta carga |

Cómo: **clic derecho** sobre el Thread Group → **Disable** (queda en gris) o **Enable** (vuelve a negro).

⚠️ **Muy importante:** si dejas varios activos, JMeter los corre uno detrás de otro y los resultados se mezclan.

**Solo para el Estrés:** haz clic en **Estres** y en el campo *Number of Threads (users)* borra `${__P(estres,0)}` y escribe **`280`**.

### Paso 2 — Limpiar resultados anteriores
Menú **Run → Clear All** (o el botón de la **escoba con dos engranajes** en la barra de arriba).

### Paso 3 — Arrancar la prueba
Presiona el botón verde **▶ Start** (o *Run → Start*). Si pregunta si quieres guardar, di **Yes**.

La prueba dura **≈ 65 segundos**. Arriba a la derecha de JMeter verás un cuadrito verde con un número tipo `10/10` (hilos activos).

### Paso 4 — Capturas DURANTE la carga (tienes ~1 minuto, ¡rápido!)

Para hacer captura: **Win + Shift + S** → selecciona la zona → se copia; pégala en Paint o haz clic en la notificación y **guarda** con el nombre indicado.

Haz estas 4, en este orden:

| # | Ventana | Qué debe verse | Guardar como |
|---|---|---|---|
| 1 | **JMeter** | Haz clic en *Summary Report* en el árbol: se ven los números subiendo + el cuadrito verde de arriba a la derecha | `jmeter-carga.png` |
| 2 | **Terminal 2** (`docker stats`) | La CPU % y MEM de `api-orders` y `db-orders` subidas | `docker-stats.png` |
| 3 | **Ubuntu** (`htop`) | Las barras de CPU de arriba llenas | `htop.png` |
| 4 | **Terminal 1** | Escribe `docker ps` y captura la salida (los 2 contenedores *Up*) | `docker-ps.png` |

### Paso 5 — Esperar a que termine
El cuadrito verde de arriba a la derecha vuelve a gris y dice `0/...`. El botón ▶ vuelve a estar activo.

### Paso 6 — Capturas AL TERMINAR

| # | Dónde | Qué debe verse | Guardar como |
|---|---|---|---|
| 5 | Clic en **Summary Report** | La fila del escenario y la fila **TOTAL** (# Samples, Average, Min, Max, Error %, Throughput) | `summary.png` |
| 6 | Clic en **Aggregate Report** | La fila con **Average, 90% Line, 95% Line, 99% Line, Error %, Throughput** | `aggregate.png` |

### Paso 7 — Guardar en la carpeta del escenario
Mueve las 6 capturas a la carpeta que corresponda (`evidences\baja-10\`, etc.).

### Paso 8 — Siguiente escenario
Vuelve al **Paso 1** con el siguiente escenario. Entre escenarios espera unos 20–30 segundos para que la CPU baje.

---

## PARTE 3 — Lista de control de capturas (24 en total)

Marca cada una cuando la tengas:

| Captura | Baja (10) | Media (50) | Alta (100) | Estrés (280) |
|---|:-:|:-:|:-:|:-:|
| 1. `jmeter-carga.png` — JMeter durante la carga | ☐ | ☐ | ☐ | ☐ |
| 2. `docker-stats.png` — docker stats durante la carga | ☐ | ☐ | ☐ | ☐ |
| 3. `htop.png` — htop durante la carga | ☐ | ☐ | ☐ | ☐ |
| 4. `docker-ps.png` — contenedores corriendo | ☐ | ☐ | ☐ | ☐ |
| 5. `summary.png` — Summary Report al terminar | ☐ | ☐ | ☐ | ☐ |
| 6. `aggregate.png` — Aggregate Report al terminar | ☐ | ☐ | ☐ | ☐ |

---

## PARTE 4 — Mandarme las capturas

Como ya están en las carpetas `jmeter\evidences\...` del proyecto, **solo avísame** ("ya están las capturas") y yo:

1. Reviso que estén las 24 y que se vean bien.
2. Las agrego dentro de `RESULTADOS_FLASK.md`, cada una en su escenario.
3. Te devuelvo el `.md` y un `.zip` listos para entregar.

Si prefieres, también puedes **arrastrarlas al chat** diciendo de qué escenario es cada una.

---

## Problemas comunes

| Problema | Solución |
|---|---|
| JMeter no abre / dice que no encuentra Java | Abre PowerShell y escribe: `$env:Path="C:\Program Files\Eclipse Adoptium\jdk-21.0.13.9-hotspot\bin;$env:Path"; & "$env:USERPROFILE\apache-jmeter-5.6.3\bin\jmeter.bat"` |
| Error % alto en JMeter / "Connection refused" | La API no está arriba: `docker compose up -d` y revisa `docker ps` |
| Los números salen distintos a `RESULTADOS_FLASK.md` | Normal: la ventana gráfica de JMeter consume CPU. En el informe se usan las métricas de la corrida por consola; las capturas son la evidencia. |
| Se mezclaron resultados de dos escenarios | Olvidaste desactivar un Thread Group. Run → Clear All y repite ese escenario. |
| `htop` muestra pocos procesos | Normal: WSL solo muestra los procesos de Ubuntu, pero las **barras de CPU** de arriba sí reflejan la carga total. Eso es lo que importa en la captura. |
| `wsl --install` falla | Activa la virtualización en la BIOS o pídeme ayuda con el mensaje de error. |

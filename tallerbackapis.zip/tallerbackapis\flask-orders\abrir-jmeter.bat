@echo off
REM Abre JMeter con el plan del grupo ya cargado.
set "PATH=C:\Program Files\Eclipse Adoptium\jdk-21.0.13.9-hotspot\bin;%PATH%"
start "" "%USERPROFILE%\apache-jmeter-5.6.3\bin\jmeterw.cmd" -t "%~dp0jmeter\benchmark-grupal.jmx"
